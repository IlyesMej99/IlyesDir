const cors = require('cors')
const express = require("express")
const app = express()
var bodyParser = require('body-parser') 
const vmRoutes = require('./routes/vmRoute')
const mdsRoutes = require('./routes/mdsRoute')
const authRoutes = require('./routes/authRoutes')

const whitelist = ["http://localhost:3000"] 

const corsOptions = {
  origin: function (origin, callback) {
    if (!origin || whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error("Not allowed by CORS"))
    }
  },
  credentials: true,
}
app.use(bodyParser.text({ limit: "50mb",  extended:true}))
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }))
app.use(cors(corsOptions))
app.use(express.json());
const options = {
  inflate: true,
  limit: 1000,
  defaultCharset: 'utf-8'
};
app.use(bodyParser.text(options));


const connectDB = require('./config/connectDB')
connectDB()

//port
const port = 5000

//use the routes
app.use('/api/', vmRoutes);
app.use('/api/auth/', authRoutes);
app.use('/api/mds/', mdsRoutes);

app.post("/upload", (req, res) => {
  // use modules such as express-fileupload, Multer, Busboy
  
  setTimeout(() => {
      console.log('file uploaded')
      return res.status(200).json({ result: true, msg: 'file uploaded' });
  }, 3000);
});

app.delete("/upload", (req, res) => {
  console.log(`File deleted`)
  return res.status(200).json({ result: true, msg: 'file deleted' });
});

app.listen(port, (error) => 
  error
    ? console.log(error)
    : console.log(`The server is running on port ${port}`)
)