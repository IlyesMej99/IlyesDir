const User = require("../models/User");
require("dotenv").config({ path: "./config/.env" });

//require bcrypyt for the hash of the password
const bcrypt = require("bcrypt");

const jwt = require("jsonwebtoken");

//register part
exports.register = async (req, res) => {
  const { email, password } = req.body;

  try {
    //check if the user exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: "User already exists !" });
    }
    user = new User({ email, password });
    //Create Salt & hash
    const salt = 10;
    const hashedPassword = await bcrypt.hash(password, salt);
    user.password = hashedPassword;
    await user.save();

    //required fields
    // if (!email || !password) {
    //   return res.status(400).json({ msg: "Please enter all the fields" });
    // }

    //create Salt & Hash

    //create new user if there is any problem

    //jswt part : generate the token
    //ps : this is optional in the register part we can redirect the user and create a tokan after the login
    const payload = {
      id: user.id,
    };
    const token = await jwt.sign(payload, process.env.secretOrKey, {
      expiresIn: "7 days",
    });
    res.status(200).send({ msg: "User registred with success", user, token });
  } catch (error) {
    res.status(500).send({ msg: "Server Error" });
  }
};

//login part
exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    //simple validation
    if (!email || !password) {
      return res.status(400).json({ msg: "Please enter all the fields" });
    }
    //check for the existant user
    let user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ msg: "Bad crids !" });
    }
    const matches = await bcrypt.compare(password, user.password);
    //check password
    if (!matches) {
      return res.status(400).send({ msg: "Bad crids !" });
    }
    //jswt part : generate the token fo the login
    const payload = {
      _id: user.id,
    };
    const token = jwt.sign(payload, process.env.secretOrKey, {
      expiresIn: "7 days",
    });
    res.send({ msg: "Logged in with success", user, token });
  } catch (error) {
    res.status(500).send({ msg: "Server Error" });
  }
};

//get user part
//private access
exports.isAuth = async (req, res) => {
  res.status(200).send({ user: req.user });
};
