const Mds = require("../models/mds");
const Vm = require("../models/Vm");
const { Client } = require("node-scp");
const SSH = require("simple-ssh");

const path = require("path");
const fs = require("fs");
const { exec } = require("child_process");

exports.addMds = async (req, res) => {
  const newMds = new Mds(req.body);

  await newMds.save();
  res.json(200);
};

//get all Mds
exports.getMds = async (req, res) => {
  try {
    const findMds = await Mds.find();
    res.status(200).json(findMds);
  } catch (error) {
    console.error(error);
    res.status(500);
  }
};

//Download a file.
exports.downloadMds = async (req, res) => {
  res.contentType(path.basename(req.query.filePath));
  res.sendFile(req.query.filePath);
};

//Get file data by path
exports.getMdsFile = async (req, res) => {
  const currVm = await Vm.findOne({ hostname: req.body.vmName });
  const data = fs.readFileSync(currVm.path + "/" + req.body.fileName, {
    encoding: "utf8",
    flag: "r",
  });

  res.status(200).json({
    fileData: data,
    path: currVm.path,
  });
};

//Edit MDS files
exports.updateFile = async (req, res) => {
  fs.writeFileSync(req.body.path, req.body.fileData);
  res.json(200);
};

//V2
//list Files by path (ls)
exports.listFiles = async (req, res) => {
  try {
    const { remoteId } = req.params;
    const { path } = req.body;
    let vmSource = await Vm.findById(remoteId);

    const client = await Client({
      host: vmSource.hostname,
      port: 22,
      username: vmSource.username,
      password: vmSource.password,
    });
    const result = await client.list(path);
    res.json(result);
    client.close(); // remember to close connection after you finish
  } catch (err) {
    res.status(500).json({
      msg: "Server error",
      err: err.stack,
    });
  }
};

/*
SSH promise function
Looks for VM and execute remote script
*/
const sshPromise = (script, remoteId) => {
  return new Promise(async (resolve, reject) => {
    let scriptOutput = "";
    let remoteVm = await Vm.findById(remoteId);
    const sshFtw = new SSH({
      host: remoteVm.hostname,
      user: remoteVm.username,
      pass: remoteVm.password,
    });
    sshFtw
      .exec(script, {
        out: function (stdout) {
          scriptOutput = stdout;
        },
      })
      .on("error", (err) => reject(err))
      .on("close", () => resolve(scriptOutput))
      .start();
  });
};
//get file content from remote
exports.readFileFromVM = async (req, res, next) => {
  const { remoteId } = req.params;
  try {
    const { filePath } = req.body;
    sshPromise("cat " + filePath, remoteId)
      .then((result) => {
        res.send(result);
      })
      .catch((e) => {
        res.status(405).json({
          msg: "Error while reading file",
          err: e.stack,
        });
      });
  } catch (err) { 
    res.status(500).json({
      msg: "Server error",
      err: err.stack, 
    });
  }
};
//edit file in remote
exports.editFileInVM = async (req, res, next) => {
  const { remoteId } = req.params;
  try {
    const { filepath } = req.headers;
    let script = "printf '" + req.body + "' > " + filepath;
    // res.send(script)
    sshPromise(script, remoteId)
      .then((result) => {
        res.status(200).json({msg:"file changed successfully !"});
      })
      .catch((e) => {
        res.status(405).json({ 
          msg: "Error while saving file",
          err: e.stack,
        });
      });
  } catch (err) {
    res.status(500).json({
      msg: "Server error",
      err: err.stack,
    });
  }
};

exports.downloadMdsbinary = async (req,res)=>{
    const {path}=req.params
    const {vmId}=req.body
    try {
      // exec('./MDS_SUITE_d_2020.3.6.3_LINUXRH6_64_arch64_Install')
      
      // sshPromise('./export/home/integ02/testtransferpack/MDS_SUITE_d_2020.3.6.3_LINUXRH6_64_arch64_Install -y',vmId).then(result=>res.send('success'))
      sshPromise(" cd /export/home/integ02/testtransferpack&&./MDS_SUITE_d_2020.3.6.3_LINUXRH6_64_arch64_Install -y", vmId)
      .then((result) => {
        res.status(200).json({msg:"file changed successfully !"});
      })
      .catch((e) => {
        res.status(405).json({ 
          msg: "Error while saving file",
          err: e.stack,
        });
      });
    } catch (error) {
      console.log(error)
    }
}