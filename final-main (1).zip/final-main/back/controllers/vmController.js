const Vm = require("../models/Vm");
const { exec } = require('child_process');
const { Client } = require('node-scp')
const SSH = require('simple-ssh');

//add Vm
exports.createVm = async (req, res) => {
  const { username, password, hostname, path } = req.body;
  try {
    const newVm = new Vm({
      username,
      password,
      hostname,
      path
    });
    const addedVm = await newVm.save();
    res.status(200).json(addedVm);
  } catch (error) {
    console.error(error);
  }
};

//get all Vms
exports.getVms = async (req, res) => {
  try {
    const findVms = await Vm.find();
    res.status(200).json(findVms);
  } catch (error) {
    console.error(error);
  }
};

//get one Vm
exports.getOneVm = async (req, res) => {
  Vm.findById(req.params.id)
    .then((vm) => res.json(vm))
    .catch((err) =>
      res.status(404).json({ msg: "No vm found with that ID" })
    );
};

//edit Vm
exports.editVm = async (req, res) => {
  const id = req.params.id;
  Vm.findByIdAndUpdate(id, req.body, { new: true })
    .then((vm) => {
      if (!vm) {
        return res.status(404).send({ msg: "Vm Not Found " });
      }
      res.send(vm);
    })
    .catch((err) => res.status(400).send({ msg: "ERROR jjj" }));
};

//delete Vm
exports.deleteVm = async (req, res) => {
  const id = req.params.id;
  Vm.findByIdAndDelete(id)
    .then((vm) => {
      if (!vm) {
        return res.status(404).send({ msg: "Vm Not Found " });
      }
      res.send(Vm);
    })
    .catch((err) => res.status(400).send({ msg: "Vm deleted .." }));
};

//connect to VM
exports.connectToVm = async (req, res) => {
  const command = "start putty.exe -ssh " + req.body.username + "@" + req.body.hostname + " -pw " + req.body.password;
  exec(command)

  res.json(200)
};

//Transfer files from VM to VM
exports.echangeVMs = async (req, res, next) => {
  const { sourceId, destId } = req.params
  try {
    //find source vm
    let vmSource = await Vm.findById(sourceId);
    //find dest VM
    let vmDest = await Vm.findById(destId);
    //begin transfer
    const { sourcePath, destinationPath } = req.body

    let folderName = sourcePath.split('/').slice(-1)[0]
    const remoteSource = await Client({
      host: vmSource.hostname,
      port: 22,
      username: vmSource.username,
      password: vmSource.password,
    })
    await remoteSource.downloadDir(sourcePath, './uploads/' + folderName)
    remoteSource.close() // remember to close connection after you finish
    //remote action

    const remoteDest = await Client({
      host: vmDest.hostname,
      port: 22,
      username: vmDest.username,
      password: vmDest.password,
    })
    await remoteDest.uploadDir('./uploads/' + folderName, destinationPath + folderName)
    remoteDest.close() // remember to close connection after you finish
    res.json({
      msg: "file transfer complete from " + sourcePath + " to " + destinationPath,
      source: vmSource,
      dest: vmDest
    })
  } catch (err) {
    console.log(err)
    res.status(500).json({
      msg: "Server error",
      err: err.stack
    })
  }

};

//Transfer files from VM to local machine (download)
exports.scpDirFromRemoteToLocal = async (req, res, next) => {
  const { sourceId } = req.params
  try {
    //find source vm
    let vmSource = await Vm.findById(sourceId);
    //begin transfer
    const { sourcePath, destinationPath } = req.body

    let folderName = sourcePath.split('/').slice(-1)[0]
    const remoteSource = await Client({
      host: vmSource.hostname,
      port: 22,
      username: vmSource.username,
      password: vmSource.password,
    })
    await remoteSource.downloadDir(sourcePath, destinationPath + '/' + folderName)
    remoteSource.close() // remember to close connection after you finish
    //remote action
    res.json({
      msg: "file transfer complete from '" + sourcePath + "' to local machine :'" + destinationPath + "'.",
      source: vmSource,
    })
  } catch (err) {
    console.log(err)
    res.status(500).json({
      msg: "Server error",
      err: err.stack
    })
  }

};

//Transfer files from local to VM (upload)
exports.scpDirFromLocalToRemote = async (req, res, next) => {
  const { destId } = req.params
  try {
    //find source vm
    let vmDist = await Vm.findById(destId);
    //begin transfer
    const { sourcePath, destinationPath } = req.body


    let folderName = sourcePath.split(/\/|\\/).slice(-1)[0]
    console.log(folderName)
    const remoteVM = await Client({
      host: vmDist.hostname,
      port: 22,
      username: vmDist.username,
      password: vmDist.password,
    })
    await remoteVM.uploadDir(sourcePath, destinationPath + '/' + folderName)

    remoteVM.close() // remember to close connection after you finish
    //remote action
    res.json({
      msg: "file transfer complete from local : '" + sourcePath + "' to VM : '" + destinationPath + "' .",
      dist: vmDist,
    })
  } catch (err) {
    console.log(err)
    res.status(500).json({
      msg: "Server error",
      err: err.stack
    })
  }

};


