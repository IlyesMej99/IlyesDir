const express = require("express");
const router = express.Router();
const {
  createVm,
  getVms,
  getOneVm,
  editVm,
  deleteVm,
  connectToVm,
  echangeVMs,
  scpDirFromRemoteToLocal,
  scpDirFromLocalToRemote
} = require("../controllers/vmController");

router.get("/vms", getVms);
router.get("/vm/:id", getOneVm);
router.post("/vm/add_vm", createVm);
router.put("/vm/:id", editVm);
router.delete("/vm/:id", deleteVm);
router.post("/vm/connect", connectToVm);
//V2
router.post("/vm/echange/:sourceId/:destId", echangeVMs);
router.post("/vm/download/:sourceId", scpDirFromRemoteToLocal);
router.post("/vm/upload/:destId", scpDirFromLocalToRemote);

module.exports = router;