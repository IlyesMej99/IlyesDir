const express = require("express");
const router = express.Router();
const {
  addMds,
  getMds,
  downloadMds,
  getMdsFile,
  updateFile,
  listFiles,
  readFileFromVM,
  editFileInVM,
  downloadMdsbinary
} = require("../controllers/mdsController");

router.get("/get", getMds);
router.post("/add", addMds);
router.get("/download", downloadMds);

router.post("/getFile", getMdsFile);
router.get("/updateFile", updateFile);

//V2
//get files in specified folder (ls)
router.post("/listFiles/:remoteId", listFiles);
router.post("/readFile/:remoteId", readFileFromVM);
router.patch("/editFile/:remoteId", editFileInVM);

router.post("/downloadBinary",downloadMdsbinary);

module.exports = router;
