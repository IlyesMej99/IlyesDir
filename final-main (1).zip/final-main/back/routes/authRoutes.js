const express = require("express");
const router = express.Router();
const { login, register, isAuth } = require("../controllers/authController");

router.post("/login", login);
router.post("/register", register);
router.get("/user", isAuth);

module.exports = router;