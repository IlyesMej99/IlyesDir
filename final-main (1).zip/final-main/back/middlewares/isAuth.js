//require jwt
const jwt = require('jsonwebtoken')

//require the user Schema
const User = require('../models/User')

const isAuth = async (req, res, next) => {
    try {
        const token = req.headers['x-auth-token']
        //check for the token 
        if (!token)
            return res.status(401).send({msg:'No token : Access denied !'})
            const decoded = await jwt.verify(token, process.env.secretOrKey)
            //add the user from paylaod
            const user = await User.findById(decoded.id)
            //check for the user
            if (!user) {
                return res.status(401).send({msg:'Access denied !'})
            }
            req.user = user
            next()
        
    } catch (error) {
        return res.status(400).json({msg:"Token is not valid"})
    }
}

module.exports = isAuth