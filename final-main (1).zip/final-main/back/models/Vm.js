const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const vmSchema = new Schema({
  username: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
    unique: true,
  },
  hostname: {
    type: String,
    required: true,
    unique: true,
  },
  path: {
    type: String,
    required: true,
    unique: true,
  }
}, { versionKey: false });

module.exports = Vm = mongoose.model("Vm", vmSchema);
