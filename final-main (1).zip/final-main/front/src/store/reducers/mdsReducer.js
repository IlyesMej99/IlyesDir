import { GET_MDSS, ADD_MDS, EDIT_MDS, DELETE_MDS } from '../constants/actionsTypes';

const initialState = {
    mdsList: [], //all mds
    isLoading: false
};

const mdsReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_MDSS:
            return {
                ...state,
                mdsList: action.payload,
                isLoading: false
            }; //payload: array of bootcamps
        // case ADD_USERS:
        //   return {
        //     ...state,
        //     users: [...state.users, action.payload],
        //   };
        case ADD_MDS:
            return {
                ...state,
                mdsList: [action.payload, ...state.mdsList]
            };
        case DELETE_MDS:
            return {
                ...state,
                mdsList: [state.mdsList.filter((mds) => mds._id !== action.payload)]
            };
        default:
            return state;
    }
};

export default mdsReducer;
