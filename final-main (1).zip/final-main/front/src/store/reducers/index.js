// // third-party
// import { combineReducers } from 'redux';

// // project import
// import menu from './menu';

// // ==============================|| COMBINE REDUCERS ||============================== //

// const reducers = combineReducers({ menu });

// export default reducers;

import { combineReducers } from 'redux';
import menu from './menu';

import vmsReducer from './vmsReducer';
import authReducer from './authReducer';
import mdsReducer from './mdsReducer';

const combineReducer = combineReducers({
    menu,
    vmsReducer,
    authReducer,
    mdsReducer
});

export default combineReducer;
