import { GET_VMS, ADD_VM, DELETE_VM, ECHANGE_VM } from '../constants/actionsTypes';

const initialState = {
    vms: [], //all vms
    isLoading: false
};

const vmsReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_VMS:
            return {
                ...state,
                vms: action.payload,
                isLoading: false
            };
        case ADD_VM:
            return {
                ...state,
                vms: [action.payload, ...state.vms]
            };
        case DELETE_VM:
            return {
                ...state,
                vms: [state.vms.filter((vm) => vm._id !== action.payload)]
            };
        case ECHANGE_VM:
            return {
                ...state,
                vms: [action.payload, ...state.vms]
            };
        default:
            return state;
    }
};

export default vmsReducer;
