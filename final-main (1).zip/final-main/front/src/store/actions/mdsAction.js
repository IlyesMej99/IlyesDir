import axios from 'axios';
import { GET_MDSS, ADD_MDS, EDIT_MDS, DELETE_MDS, GET_MDS_FILES } from '../constants/actionsTypes';

export const getMdss = () => (dispatch) => {
    axios
        .get('http://localhost:5000/api/mds/get')
        .then((res) => {
            dispatch({
                type: GET_MDSS,
                payload: res.data
            });
        })
        .catch((err) => console.error(err));
};

export const addMds = (newMds) => (dispatch) => {
    axios
        .post('http://localhost:5000/api/mds/add', newMds)
        .then((res) => {
            dispatch({
                type: ADD_MDS,
                payload: res.data
            });
            document.getElementById('successMsg').style.display = 'block';
        })
        .catch((err) => console.error(err));
};

//V2
export const getMdsFiles = (remoteId) => (dispatch) => {
    axios
        .get(`http://localhost:5000/api/mds/listFiles/${remoteId}`)
        .then((res) => {
            dispatch({
                type: GET_MDS_FILES,
                payload: res.data
            });
        })
        .catch((err) => console.error(err));
};

// export const editMds = (_id, formData) => async (dispatch) => {
//     await axios
//         .put(`http://localhost:5000/api/mds/${_id}`, formData)
//         .then((res) => dispatch(getMdss()))
//         .catch((err) => {
//             err.response.data = { msg: 'Error to put the MDS ' };
//         });
// };

// export const removeMds = (_id) => async (dispatch) => {
//     await axios
//         .delete(`http://localhost:5000/api/vm/${_id}`)
//         .then((res) => dispatch(getMdss()))
//         .catch((err) => {
//             err.response.data = { msg: 'Error to delete the VM ' };
//         });
// };
