import axios from 'axios';
import { GET_VMS, ADD_VM, EDIT_VM, DELETE_VM, ECHANGE_VM, DOWNLOAD_FROM_VM, UPLOAD_TO_VM } from '../constants/actionsTypes';

export const getVms = () => (dispatch) => {
    axios
        .get('/api/vms')
        .then((res) => {
            dispatch({
                type: GET_VMS,
                payload: res.data
            });
        })
        .catch((err) => console.error(err));
};

export const addVm = (newVm) => (dispatch) => {
    axios
        .post('http://localhost:5000/api/vm/add_vm', newVm)
        .then((res) => {
            dispatch({
                type: ADD_VM,
                payload: res.data
            });
            document.getElementById('successMsg').style.display = 'block';
        })
        .catch((err) => console.error(err));
};

export const editVm = (_id, formData) => async (dispatch) => {
    await axios
        .put(`http://localhost:5000/api/vm/${_id}`, formData)
        .then((res) => dispatch(getVms()))
        .catch((err) => {
            err.response.data = { msg: 'Error to put the VM ' };
        });
};

export const removeVm = (_id) => async (dispatch) => {
    await axios
        .delete(`http://localhost:5000/api/vm/${_id}`)
        .then((res) => dispatch(getVms()))
        .catch((err) => {
            err.response.data = { msg: 'Error to delete the VM ' };
        });
};

//echange file from a VM to an other VM
export const echangeVms = (sourceId, destId, paths) => async (dispatch) => {
    await axios
        .post(`http://localhost:5000/api/vm/echange/${sourceId}/${destId}`, paths)
        .then((res) => {
            dispatch({
                type: ECHANGE_VM,
                payload: res.data
            });
            document.getElementById('successMsg').style.display = 'block';
        })
        .catch((err) => console.error(err));
};

//download a file from a VM to local
export const downloadFromVm = (sourceId, paths) => async (dispatch) => {
    await axios
        .post(`http://localhost:5000/api/vm/download/${sourceId}`, paths)
        .then((res) => {
            dispatch({
                type: DOWNLOAD_FROM_VM,
                payload: res.data 
            });
            document.getElementById('successMsg').style.display = 'block';
        })
        .catch((err) => console.error(err));
};

//upload a file from local to remote vm
export const uploadToVm = (destId, paths) => async (dispatch) => {
    await axios
        .post(`http://localhost:5000/api/vm/upload/${destId}`, paths)
        .then((res) => {
            dispatch({
                type: UPLOAD_TO_VM,
                payload: res.data
            });
            document.getElementById('successMsg').style.display = 'block';
        })
        .catch((err) => console.error(err));
};