// third-party
// import { configureStore } from '@reduxjs/toolkit';

// // project import
// import reducers from './reducers';

// // ==============================|| REDUX TOOLKIT - MAIN STORE ||============================== //

// const store = configureStore({
//     reducer: reducers
// });

// const { dispatch } = store;

// export { store, dispatch };

import { createStore, compose, applyMiddleware } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import rootReducer from './reducers';

const middlware = [thunk];

const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(...middlware)));

export default store;
