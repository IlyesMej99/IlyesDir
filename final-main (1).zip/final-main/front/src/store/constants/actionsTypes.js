//AUTHENTIFICATION
export const USER_LOADING = 'USER_LOADING'
export const LOGIN_USER = 'LOGIN_USER'
export const REGISTER_USER = 'USER_LOADING'
export const LOGOUT_USER = 'LOGOUT_USER'
export const GET_AUTH_USER = 'GET_AUTH_USER'
export const AUTH_ERRORS = 'AUTH_ERRORS'

//VMS : ACTION TYPES
export const GET_VMS = "GET_VMS";
export const ADD_VM = "ADD_VM";
export const EDIT_VM = "EDIT_VM"
export const DELETE_VM = "DELETE_VM";
//v2
export const ECHANGE_VM = "ECHANGE_VM";
export const DOWNLOAD_FROM_VM = "DOWNLOAD_FROM_VM";
export const UPLOAD_TO_VM = "UPLOAD_TO_VM";

//MDS : ACTION TYPES
export const GET_MDSS = "GET_MDSS";
export const ADD_MDS = "ADD_MDS";
export const EDIT_MDS = "EDIT_MDS"
export const DELETE_MDS = "DELETE_MDS";
//v2
export const GET_MDS_FILES = "GET_MDS_FILES";