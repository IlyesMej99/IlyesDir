import { useEffect } from 'react';
import { Box, Typography } from '@mui/material/';
import { useSelector, useDispatch } from 'react-redux';
import { getVms } from '../../../store/actions/vmsAction';
import CardVm from './cardVm';

export default function ListVms() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getVms());
    }, []);

    const vms = useSelector((state) => state.vmsReducer.vms);
    return (
        <div style={{ height: 400, width: '100%' }}>
            <Box sx={{ display: 'flex', position: 'relative' }}>
                <Typography sx={{ position: 'absolute', left: '735px' }}>Connection</Typography>
                <Typography sx={{ position: 'absolute', left: '270px' }}>Virtual machine</Typography>
            </Box>

            <Box sx={{ mt: '50px', }}>
                {vms.map((vm) => (
                    <CardVm key={vm._id} username={vm.username} password={vm.password} hostname={vm.hostname} path={vm.path} />
                ))}
            </Box>
        </div>
    );
}
