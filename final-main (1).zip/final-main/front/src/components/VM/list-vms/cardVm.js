import { Box, Typography, Button } from '@mui/material/';
import axios from 'axios';

export default function CardVm(props) {
    const connectToVM = async () => {
        await axios.post('http://localhost:5000/api/vm/connect', {
            username: props.username,
            password: props.password,
            hostname: props.hostname,
            path: props.path
        });
    };

    return (
        <Box sx={{ position:'relative', width: '600px', ml: '250px', height: '70px', marginBottom: '25px', backgroundColor: 'white', borderRadius: '5px' }}>
            <Box sx={{ display: 'flex' }}>
                <Box>
                    <Typography variant="h4" sx={{ pt: '20px', pl: '25px' }}>
                        {props.hostname}
                    </Typography>
                </Box>
                <Box sx={{ ml: '480px', pt: '15px', position:'absolute' }}>
                    <Button onClick={connectToVM} variant="outlined">
                        Connect
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}
