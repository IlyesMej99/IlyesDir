import { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { addVm } from '../../../store/actions/vmsAction';
import { Box, TextField, Button, Typography } from '@mui/material';

export default function AddVM() {
    const dispatch = useDispatch();
    const addNewVm = (formData) => dispatch(addVm(formData));
    const [form, setForm] = useState({
        username: '',
        password: '',
        hostname: '',
        path: ''
    });

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        addNewVm(form);
    };

    return (
        <Box sx={{ backgroundColor: 'white', width: '700px', height: '470px', ml: '100px' }}>
            <Box sx={{ display: 'block', mt: '50px', ml: '100px', pt: '50px' }}>
                <Typography variant="h4">Add a virtual machine</Typography>
                <form onSubmit={handleSubmit}>
                    <Box sx={{ width: '200px', mt: '30px' }}>
                        <TextField
                            sx={{ width: '450px', mb: '30px' }}
                            id="outlined-basic"
                            name="username"
                            label="username"
                            variant="outlined"
                            onChange={handleChange}
                            value={form.username}
                        />
                    </Box>
                    <Box sx={{ display: 'block' }}>
                        <TextField
                            sx={{ width: '450px', mb: '30px' }}
                            id="outlined-basic"
                            name="password"
                            label="password"
                            variant="outlined"
                            onChange={handleChange}
                            value={form.password}
                        />
                    </Box>
                    <Box sx={{ display: 'block' }}>
                        <TextField
                            sx={{ width: '450px', mb: '30px' }}
                            id="outlined-basic"
                            name="hostname"
                            label="hostname"
                            variant="outlined"
                            onChange={handleChange}
                            value={form.hostname}
                        />
                    </Box>
                    <Box sx={{ display: 'block' }}>
                        <TextField
                            sx={{ width: '450px', mb: '30px' }}
                            id="outlined-basic"
                            name="path"
                            label="path"
                            variant="outlined"
                            onChange={handleChange}
                            value={form.path}
                        />
                    </Box>
                    <p id="successMsg" style={{ marginTop: '-15px', marginBottom: '15px', color: '#1890ff', display: 'none' }}>
                        VM Added Successfully !
                    </p>
                    <Box sx={{ ml: '100px' }}>
                        <Button variant="contained" type="submit" sx={{backgroundColor:'#f55321'}}>
                            Submit
                        </Button>
                        <Button sx={{ backgroundColor: 'gray', ml: '30px',  }} variant="contained">
                            Cancel
                        </Button>
                    </Box>
                </form>
            </Box>
        </Box>
    );
}
