import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';
import { Box, Button, TextField, Grid, Typography, MenuItem, Container } from '@mui/material';
import { getVms, echangeVms } from 'store/actions/vmsAction';
import { method } from 'lodash';

export default function EchangeVMs() {
    const dispatch = useDispatch();
    const vms = useSelector((state) => state.vmsReducer.vms);
    useEffect(() => {
        dispatch(getVms());
    }, []);
    //const [vms, setVms] = useState([]);
    const [vmSrc, setVmSrc] = useState('');
    const [vmDest, setVmDest] = useState('');
    //source file path
    const [srcFilePath, setSrcFilePath] = useState('');
    //destination file path
    const [destFilePath, setDestFilePath] = useState('');

    // let sourceID = vms && vms?.map((res) => ({ vmSrc: res._id }));
    // let destID = vms && vms?.map((res) => ({ vmDest: res._id }));
    // console.log("source",sourceID);
    // console.log(destID);

    const handleEchange = (e) => {
        e.preventDefault();

        // axios.post('http://localhost:5000/api/vm/echange', {
        //     vmFrom: vms.filter((obj) => obj.hostname === vmFrom)[0].path,
        //     vmTo: vms.filter((obj) => obj.hostname === vmTo)[0].path,
        //     filePath
        // });
    };
    const sourceId =vmSrc && vms.find(e=>e.hostname===vmSrc)._id
    const destinationId =vmDest && vms.find(e=>e.hostname===vmDest)._id
    const handleTransfert = async () => {await axios.post(`http://localhost:5000/api/vm/echange/${sourceId}/${destinationId}`,{
                                sourcePath:srcFilePath,
                                destinationPath:destFilePath
                                }).catch(err=>console.log(err)) }

    
    // useEffect(() => {
    //     axios.get('http://localhost:5000/api/vms').then((res) => {
    //         setVms(res.data);
    //         setVmFrom(res.data[0].hostname);
    //     });
    // }, []);

    return (
        <Container component="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                }}
            >
                <Typography component="h1" variant="h5">
                    Transfer files between VMs
                </Typography>
                <Box component="form" noValidate sx={{ mt: 3 }}>
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <TextField
                                label="Select the source VM"
                                id="standard-select-currency"
                                size="small"
                                select
                                value={vmSrc}
                                onChange={(e) => setVmSrc(e.target.value)}
                                setVmSrc={vmSrc}
                                style={{ width: '100%' }}
                                sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                            >
                                {vms.map((vm, index) => (
                                    <MenuItem key={`vm-${index}`} value={vm.hostname} >
                                        {vm.hostname}
                                    </MenuItem>
                                ))}
                            </TextField>
                            <TextField
                                required
                                fullWidth
                                id="email"
                                label="Source : File Path"
                                value={srcFilePath}
                                setSrcFilePath={srcFilePath}
                                onChange={(e) => setSrcFilePath(e.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                label="Select the destination VM"
                                id="standard-select-currency"
                                size="small"
                                select
                                value={vmDest}
                                onChange={(e) => setVmDest(e.target.value)}
                                setVmDest={vmDest}
                                style={{ width: '100%' }}
                                sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                            >
                                {vms.map((vm, index) => (
                                    <MenuItem key={`vm-${index}`} value={vm.hostname}>
                                        {vm.hostname}
                                    </MenuItem>
                                ))}
                            </TextField>
                            <TextField
                                required
                                fullWidth
                                id="email"
                                label="Source : File Path"
                                value={destFilePath}
                                setDestFilePath={destFilePath}
                                onChange={(e) => setDestFilePath(e.target.value)}
                            />
                        </Grid>
                    </Grid>
                    <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ mt: 3, mb: 2,  backgroundColor:'#f55321' }}
                            onClick={handleTransfert}
                        >Transfert</Button>
                </Box>
            </Box>
        </Container>
    );
}
