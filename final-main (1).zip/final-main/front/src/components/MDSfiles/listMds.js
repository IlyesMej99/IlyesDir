import { Box, Typography, Select } from '@mui/material/';
import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getMdss } from '../../store/actions/mdsAction';
import CardMds from '../../components/MDSfiles/cardMds';
import { getVms } from 'store/actions/vmsAction';
import { Button, Container, Grid, MenuItem, TextField } from '../../../node_modules/@mui/material/index';
import axios from 'axios'
 export default function ListMds() {
     const dispatch = useDispatch();
    const [vmSrc, setVmSrc] = useState('');
    //source file path
    const [srcFilePath, setSrcFilePath] = useState('');
    const [result, setResult] = useState([]);
    const vms = useSelector((state) => state.vmsReducer.vms);
    const handleSubmit = async (e) => {
        e.preventDefault()
        const result = await axios.post(`http://localhost:5000/api/mds/listFiles/${vmSrc}`, {
                    path:srcFilePath
                  })
        const data = await result.data
        setResult(...data)
        //  await axios
        //      .post(`http://localhost:5000/api/mds/listFiles/631cdfdba1dade94e47c6292`, {
        //          path: srcFilePath
        //      })
        //     .then((res) => {
        //          alert(result);
        //      })
        //      .catch((err) => alert(err));
     };
    useEffect(() => {
        dispatch(getVms());
    }, []);

     const mdsList = useSelector((state) => state.mdsReducer.mdsList);
     return (
         <Box component="main" maxWidth="xs">
            {
             console.log(result)
            /* {
                                 result && <h1>{result[0].name}</h1>
             } */}
             <Box sx={{  marginTop: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                 <Typography component="h1" variant="h5">
                    
                MDS Files list
                 </Typography>
                 <Box component="form" noValidate sx={{ mt: 3 }}>
                    {/* <Box sx={{ mb:'30px', }}> */}
                     <TextField
                         label="Select the destination VM"
                         id="standard-select-currency"
                         size="small"
                         style={{ width: '100%' }}
                         select
                         onChange={(e) => setVmSrc(e.target.value)}
                         sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                     >
                         {vms.map((vm, index) => (
                             <MenuItem key={index} value={vm._id}>
                                 {vm.hostname}
                             </MenuItem>
                         ))}
                     </TextField>
                     {/* </Box> */}

                      <TextField
                        required
                         fullWidth
                         id="email"
                         label="Source : File Path"
                         style={{ width: '100%' }}
                         sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                         onChange={(e) => setSrcFilePath(e.target.value)}
                     />
                   <Button onClick={handleSubmit} type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2, backgroundColor:'#f55321'  }}>
                        get list
                    </Button>
             </Box>
           </Box>
           <Box sx={{  }}>
                <CardMds fileName={result && result?.name} rights={result && result?.rights?.user} groupe={result && result?.rights?.group} size={result && result?.size}/>
           </Box>
         </Box>
     );
 }


