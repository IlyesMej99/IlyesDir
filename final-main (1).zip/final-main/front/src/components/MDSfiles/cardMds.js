import { Box, Button } from '@mui/material/';
import EditMDS from '../MDSfiles/editMDS';
import { Link } from 'react-router-dom';

export default function CardMds(props) {
    return (
        <Box
            style={{
                position: 'relative',
                width: '100%',
                ml: '250px',
                marginBottom: '25px',
                backgroundColor: 'white',
                borderRadius: '10px',
                border: 'solid rgba(128, 128, 128, 0.15)',
                padding: '10px 0 10px 30px'
            }}
        >
            {/* <Link to={`/EditMDS?vmName=${props.vmName}&fileName=${props.fileName}`}>
                <Button
                    style={{
                        top: '15px',
                        right: '15px',
                        position: 'absolute',
                        border: 'solid #1890ff 1px',
                        color: '#1890ff',
                        fontFamily: '"Public Sans", sans-serif',
                        background: '#fff'
                    }}
                >
                    Edit
                </Button>
            </Link> */}

            <span style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <h3>File Name :</h3>
                <h2>{props.fileName}</h2>
            </span>

            <span style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <h3>Rights :</h3>
                <h2>{props.rights}</h2>
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <h3>Groupe :</h3>
                <h2>{props.groupe}</h2>
            </span>

            <span style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                <h3>Size:</h3>
                <h2>{props.size}</h2>
            </span>
        </Box>
    );
}
