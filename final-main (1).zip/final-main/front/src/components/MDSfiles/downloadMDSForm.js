// import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import { useSelector, useDispatch } from 'react-redux';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { MenuItem } from '@mui/material';
import { getVms } from '../../store/actions/vmsAction';

import { useState, useEffect } from 'react';
import { saveAs } from 'file-saver';
import fileDownload from 'js-file-download';
import axios from 'axios';

export default function DownloadMDSForm() {
    const dispatch = useDispatch();
    //const [vms, setVms] = useState([]);
    const [selectedVm, setSelectedVm] = useState('');
    const [vmSrc, setVmSrc] = useState(0);
    const [fileName, setFileName] = useState('');
    const [result, setResult] = useState();
    

    useEffect(() => {
        dispatch(getVms());
        if(result){

            let string = result.replaceAll(/\;/g,'<br/>')
            document.getElementById('out').innerHTML = string
        }
   
    }, [result]);
    const vms = useSelector((state) => state.vmsReducer.vms);

    // useEffect(() => {
    //   axios.get("http://localhost:5000/api/vms")
    //   .then(res => {
    //     setVms(res.data);
    //     setSelectedVm(res.data[0].hostname);
    //   })
    // }, [])
    // console.log(vms)
    const handleSubmit = async (e) => {
        e.preventDefault()
        await axios
            .post(`http://localhost:5000/api/mds/readFile/${vmSrc}`, {
                filePath: fileName
            })
            .then((res) => {
                setResult(res.data)
            })
            .catch((err) => console.log(err));
    };

    return (
        <Container component="main" maxWidth="xl" sx={{}}>
            { console.log(result)}
            {/* <CssBaseline /> */}
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                }}
            >
                {/* <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
            <LockOutlinedIcon />
          </Avatar> */}
                <Typography component="h1" variant="h5">
                    Get  MDS  File Content 
                </Typography>
                <Box component="form" noValidate sx={{ mt: 3 }}>
                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}></Grid>
                        <Grid item xs={12}>
                            <TextField
                                label="Select the destination VM"
                                id="standard-select-currency"
                                size="small"
                                style={{ width: '100%' }}
                                select
                                onChange={(e) => setVmSrc(e.target.value)}
                                sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                            >
                                {vms.map((vm, index) => (
                                    <MenuItem key={`vm-${index}`} value={vm._id}>
                                        {vm.hostname}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                required
                                fullWidth
                                id="email"
                                label="The destination"
                                name="email"
                                autoComplete="email"
                                value={fileName}
                                onChange={(e) => setFileName(e.target.value)}
                            />
                        </Grid>
                    </Grid>

                    <Button onClick={handleSubmit} type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2, backgroundColor:'#f55321' }}>
                        get content
                    </Button>
                    
                </Box>
            </Box>
            <div id='out'>
            </div>
        </Container>
    );
}
