import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import { useSelector, useDispatch } from 'react-redux';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { MenuItem } from '@mui/material';
import { getVms } from '../../store/actions/vmsAction';
import axios from 'axios';
import vm from 'menu-items/vm';

export default function EditMDS() {
    const [vmSrc, setVmSrc] = useState('');
    const [filePath, setFilePath] = useState('');
    const [command, setCommand] = useState('');
    const [msg, setMsg] = useState('');

    const dispatch = useDispatch();
    const vms = useSelector((state) => state.vmsReducer.vms);
    const config={
        headers:{
           // 'Content-length':0,
            'Content-Type': 'text/plain',
            'filepath': `${filePath}`
        },responseType:'text/plain'
    }
    const handleSubmit = async (e) => {
        e.preventDefault()
        await axios
            .patch(`http://localhost:5000/api/mds/editFile/${vmSrc}`,command,config
           ).then(res=>setMsg(res.data.msg))
            .catch((err) => console.log(err));
    };

    useEffect(() => {
        dispatch(getVms());
    }, []);

    return (
        <Container component="main" maxWidth="xl" sx={{}}>
            {/* <CssBaseline /> */}
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                }}
            >
                {/* <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
            <LockOutlinedIcon />
          </Avatar> */}
                <Typography component="h1" variant="h5">
                   configure MDS file
                </Typography>
                <Box component="form" noValidate sx={{ mt: 3 }}>
                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}></Grid>
                        <Grid item xs={12}>
                            <TextField
                                label="Select the destination VM"
                                id="standard-select-currency"
                                size="small"
                                style={{ width: '100%' }}
                                select
                                onChange={(e) => setVmSrc(e.target.value)}
                                sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                            >
                                {vms.map((vm, index) => (
                                    <MenuItem key={`vm-${index}`} value={vm._id}>
                                        {vm.hostname}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                
                                fullWidth
                                id="email"
                                label="The destination"
                                name="email"
                                autoComplete="email"
                                value={filePath}
                                onChange={(e) => setFilePath(e.target.value)}
                            />
                    <textarea onChange={e=>setCommand(e.target.value)} style={{marginTop:20,width:'100%'}} rows={5}/>
                        </Grid>
                    </Grid>
                    <Button onClick={handleSubmit} type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2, backgroundColor:'#f55321' }}>
                        configure 
                    </Button>
                     <span style={{color:'green'}}>{msg}</span>
                </Box>
            </Box> 
           
        </Container>
    );
}
