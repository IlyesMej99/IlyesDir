// assets
import { DashboardOutlined } from '@ant-design/icons';

// icons
const icons = {
    DashboardOutlined
};

// ==============================|| MENU ITEMS - DASHBOARD ||============================== //

const mds = {
    id: 'group-dashboard',
    title: 'MDS files',
    type: 'group',
    children: [
        {
            id: 'List MDS',
            title: 'List MDS files',
            type: 'item',
            url: '/mdsFiles',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'Read MDS',
            title: 'Read MDS file',
            type: 'item',
            url: '/downloadMDS',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'Edit MDS',
            title: 'Edit MDS file',
            type: 'item',
            url: '/EditMds',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'Compare MDS',
            title: 'Compare MDS file',
            type: 'item',
            url: '/CompareMds',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        }
    ]
};

export default mds;
