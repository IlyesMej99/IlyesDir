// project import
import dashboard from './dashboard';
import vm from './vm';
import mds from './mds';

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
    items: [dashboard, vm, mds]
};

export default menuItems;
