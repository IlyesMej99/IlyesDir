// assets
import { DashboardOutlined } from '@ant-design/icons';

// icons
const icons = {
    DashboardOutlined
};

// ==============================|| MENU ITEMS - DASHBOARD ||============================== //

const vm = {
    id: 'group-dashboard',
    title: 'VM',
    type: 'group',
    children: [
        {
            id: 'connect',
            title: 'Connect to VM',
            type: 'item',
            url: '/ConnectVM',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'add',
            title: 'Add VM',
            type: 'item',
            url: '/AddVM',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'Transfer VMs',
            title: 'Transfer VMs',
            type: 'item',
            url: '/echangeVMs',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'Download from VM',
            title: 'Download from VM',
            type: 'item',
            url: '/DownlaodFromVM',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        },
        {
            id: 'Upload to VM',
            title: 'Upload to VM',
            type: 'item',
            url: '/uploadToVM',
            icon: icons.DashboardOutlined,
            breadcrumbs: false
        }
    ]
};

export default vm;
