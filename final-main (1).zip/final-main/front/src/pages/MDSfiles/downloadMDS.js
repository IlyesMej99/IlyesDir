import { Box } from '@mui/material';
import DownloadMDSForm from 'components/MDSfiles/downloadMDSForm';

export default function DownloadMDS() {
    return (
        <Box>
            <DownloadMDSForm />
        </Box>
    );
}
