import Button from '@mui/material/Button';
// import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
// import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { MenuItem } from '@mui/material';

import { useState, useEffect } from 'react';
import axios from 'axios';

export default function DownloadMDS() {
    const [vms, setVms] = useState([]);

    const [vmFrom, setVmFrom] = useState('');
    const [vmTo, setVmTo] = useState('');
    //source file path
    const [srcFilePath, setSrcFilePath] = useState('');
    //destination file path
    const [destFilePath, setDFestFilePath] = useState('');

    const handleEchange = (e) => {
        e.preventDefault();

        // axios.post('http://localhost:5000/api/vm/echange', {
        //     vmFrom: vms.filter((obj) => obj.hostname === vmFrom)[0].path,
        //     vmTo: vms.filter((obj) => obj.hostname === vmTo)[0].path,
        //     filePath
        // });
    };

    // useEffect(() => {
    //     axios.get('http://localhost:5000/api/vms').then((res) => {
    //         setVms(res.data);
    //         setVmFrom(res.data[0].hostname);
    //     });
    // }, []);

    return (
        <Box sx={{border:'red 1px solid'}}>
            <Container component="main" maxWidth="xs">
                <Box
                    sx={{
                        marginTop: 8,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center'
                    }}
                >
                    <Typography component="h1" variant="h5">
                        Transfer files between VMs
                    </Typography>
                    <Box component="form" noValidate sx={{ mt: 3 }}>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}></Grid>
                            <Grid item xs={12}>
                                <TextField
                                    required
                                    fullWidth
                                    id="email"
                                    label="Source : File Path"
                                    value={srcFilePath}
                                    onChange={(e) => setSrcFilePath(e.target.value)}
                                />
                                <TextField
                                    required
                                    fullWidth
                                    id="email"
                                    label="Source : File Path"
                                    value={destFilePath}
                                    onChange={(e) => setDFestFilePath(e.target.value)}
                                />
                                
                            </Grid>

                            {/* <Grid item xs={12}>
                                <TextField
                                    id="standard-select-currency"
                                    size="small"
                                    select
                                    value={vmFrom}
                                    onChange={(e) => setVmFrom(e.target.value)}
                                    style={{ width: '100%' }}
                                    sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                                >
                                    {vms.map((vm, index) => (
                                        <MenuItem key={`vm-${index}`} value={vm.hostname}>
                                            {vm.hostname}
                                        </MenuItem>
                                    ))}
                                </TextField>
                            </Grid> */}

                            {/* <Grid item xs={12}>
                                <TextField
                                    id="standard-select-currency"
                                    size="small"
                                    select
                                    value={vmTo}
                                    onChange={(e) => setVmTo(e.target.value)}
                                    style={{ width: '100%' }}
                                    sx={{ '& .MuiInputBase-input': { py: 0.5, fontSize: '0.875rem' } }}
                                >
                                    {vms
                                        .filter((obj) => obj.hostname !== vmFrom)
                                        .map((vm, index) => (
                                            <MenuItem key={`vm-${index}`} value={vm.hostname}>
                                                {vm.hostname}
                                            </MenuItem>
                                        ))}
                                </TextField>
                            </Grid> */}
                        </Grid>

                        <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2, backgroundColor:'#f55321' }} onClick={handleEchange}>
                            Transfer
                        </Button>
                    </Box>
                </Box>
            </Container>
        </Box>
    );
}
