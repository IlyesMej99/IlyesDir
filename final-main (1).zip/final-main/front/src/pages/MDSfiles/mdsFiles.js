import { Box } from '@mui/material/';
// import ListFiles from 'pages/MDSfiles/listVms';
import ListMds from '../../components/MDSfiles/listMds';
// import ListVM from './VM/listVM';

export default function ConnectVM() {
    return (
        <Box>
            <ListMds />
        </Box>
    );
}
