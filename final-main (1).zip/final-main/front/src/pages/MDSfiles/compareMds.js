import React , { useState } from 'react';
import FileUpload from '../../components/MDSfiles/upload/fileUpload';
import FileList from '../../components/MDSfiles/upload/fileList';
import { Box, Typography } from '@mui/material';

export default function Comparemds() {
    const [files, setFiles] = useState([]);

    const removeFile = (filename) => {
        setFiles(files.filter((file) => file.name !== filename));
    };

    return (
        <div className="App">
            <Typography className="title" sx={{fontSize:'30px', mb:'100px', textAlign:"center"}}>Upload file</Typography>
            <FileUpload files={files} setFiles={setFiles} removeFile={removeFile} />
            <FileList files={files} removeFile={removeFile} />
        </div>
    );
}
