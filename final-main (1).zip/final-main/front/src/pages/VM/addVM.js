import { Box } from '@mui/material';
import AddVM from 'components/VM/add-vm/addVm';

export default function AddVMPage() {
    return (
        <Box>
            <AddVM />
        </Box>
    );
}
