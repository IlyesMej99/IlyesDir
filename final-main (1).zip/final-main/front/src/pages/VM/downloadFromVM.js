import { Box } from '@mui/material';
import DownloadFromVM from 'components/VM/download-from-vm/downloadFromVm';

export default function DownloadFromVmPage() {
  return (
    <Box>
        <DownloadFromVM />
    </Box>
  )
}
