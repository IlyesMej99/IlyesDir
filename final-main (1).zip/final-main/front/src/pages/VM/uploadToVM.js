import { Box } from '@mui/material';
import UploadToVM from 'components/VM/upload-to-vm/uploadToVM';

export default function UploadToVMPage() {
    return (
        <Box>
            <UploadToVM />
        </Box>
    );
}
