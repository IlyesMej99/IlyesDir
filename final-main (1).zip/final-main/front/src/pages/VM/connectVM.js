import { Box } from '@mui/material/';
import ListVms from '../../components/VM/list-vms/listVm';

export default function ConnectVM() {
    return (
        <Box>
            <ListVms />
        </Box>
    );
}
