import { Box } from '@mui/material';
import EchangeVMs from 'components/VM/echange-vms/echangeVMs';

export default function EchangeVMsPage() {
    return (
        <Box>
            <EchangeVMs/>
        </Box>
    );
}
