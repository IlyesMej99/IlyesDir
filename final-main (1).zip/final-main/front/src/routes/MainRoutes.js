import { lazy } from 'react';

// project import
import Loadable from 'components/Loadable';
import MainLayout from 'layout/MainLayout';
import DownloadMDS from 'pages/MDSfiles/downloadMDS';
import EchangeVMs from 'pages/VM/echangeVMs';
import DownloadFromVmPage from 'pages/VM/downloadFromVM';
import UploadToVMPage from 'pages/VM/uploadToVM';
import CompareMds from 'pages/MDSfiles/compareMds';
import Dignostic from 'components/MDSfiles/dignostic';

// render - dashboard
const DashboardDefault = Loadable(lazy(() => import('pages/dashboard')));
const ConnectVM = Loadable(lazy(() => import('pages/VM/connectVM')));
const AddVM = Loadable(lazy(() => import('pages/VM/addVM')));
const MdsFiles = Loadable(lazy(() => import('pages/MDSfiles/mdsFiles')));
const EditMDS = Loadable(lazy(() => import('components/MDSfiles/editMDS')));

// render - sample page

// render - utilities
const Color = Loadable(lazy(() => import('pages/components-overview/Color')));

// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
    path: '/',
    element: <MainLayout />,
    children: [
        {
            path: '/',
            element: <DashboardDefault />
        },
        {
            path: 'color',
            element: <Color />
        },
        {
            path: 'dashboard',
            children: [
                {
                    path: '',
                    element: <DashboardDefault />
                }
            ]
        },
        {
            path: 'connectVM',
            children: [
                {
                    path: '',
                    element: <ConnectVM />
                }
            ]
        },
        {
            path: 'AddVM',
            children: [
                {
                    path: '',
                    element: <AddVM />
                }
            ]
        },
        {
            path: 'DownlaodFromVM',
            children: [
                {
                    path: '',
                    element: <DownloadFromVmPage />
                }
            ]
        },
        {
            path: 'UploadToVM',
            children: [
                {
                    path: '',
                    element: <UploadToVMPage />
                }
            ]
        },
        {
            path: 'MDSFiles',
            children: [
                {
                    path: '',
                    element: <MdsFiles />
                }
            ]
        },
        {
            path: 'DownloadMDS',
            children: [
                {
                    path: '',
                    element: <DownloadMDS />
                }
            ]
        },
        {
            path: 'EchangeVMs',
            children: [
                {
                    path: '',
                    element: <EchangeVMs />
                }
            ]
        },
        {
            path: 'EditMDS',
            children: [
                {
                    path: '',
                    element: <EditMDS />
                }
            ]
        },
        {
            path: 'CompareMDS',
            children: [
                {
                    path: '',
                    element: <CompareMds />
                }
            ]
        },
        {
            path: 'Dignostic',
            children: [
                {
                    path: '',
                    element: <Dignostic />
                }
            ]
        }
    ]
};

export default MainRoutes;
